package com.cg;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainApp {

	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
		
		SBU sbu = context.getBean(SBU.class, "sbu");
		System.out.println("SBU Details\n----------------------------------------");
		System.out.println(sbu);
	}

}
